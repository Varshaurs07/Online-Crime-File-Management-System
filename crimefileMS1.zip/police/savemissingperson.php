<?php

session_start();

require "../config/database.php";

date_default_timezone_set('Asia/Kolkata');

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    if (isset($_POST['savemissingperson'])) 
    {
        $state = true;
 
        $name = mysqli_real_escape_string($link, trim($_POST['name'])); 
        $alias = mysqli_real_escape_string($link, trim($_POST['alias']));  
        $missingdate = mysqli_real_escape_string($link, trim($_POST['missingdate'])); 
        $missinglocation = mysqli_real_escape_string($link, trim($_POST['missinglocation']));  
        $status = mysqli_real_escape_string($link, trim($_POST['status'])); 
        $age = mysqli_real_escape_string($link, trim($_POST['age']));   
        // $uid = mysqli_real_escape_string($link, trim($_POST['uid']));  

        $uid = "uid_".substr(bin2hex(random_bytes(10)),0, 10);
        
        if ($_FILES["image"]["size"] !== 0) 
        {
            $errors = null;
            $file_name = $_FILES['image']['name'];
            $file_size = $_FILES['image']['size'];
            $file_tmp = $_FILES['image']['tmp_name'];
            $file_type = $_FILES['image']['type'];
            $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);

            move_uploaded_file($file_tmp, "../docs/" . $file_name);

            $image = "docs/" . $file_name;

            $query = " insert into crime_2023_missingperson (uid,name,alias,missingdate,missinglocation,status,image,age) values ('$uid','$name','$alias','$missingdate','$missinglocation','$status','$image','$age') ";

            if (!mysqli_query($link, $query)) 
            {
                $state = false;
            }
        }
  

            if ($state) 
            {
                $_SESSION["save"] = "yes";
                echo "<script> location.replace('addmissingperson.php') </script>";
            } 
            else 
            {
                $_SESSION["fail"] = "yes";
                echo "<script> location.replace('addmissingperson.php') </script>";
            }
    } 
    else 
    {
        echo "<script> location.replace('addmissingperson.php') </script>";
    }

    mysqli_close($link);
}
